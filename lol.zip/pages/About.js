import Head from "next/head";
import Footer from "../components/Footer";
import Script1 from "../components/Script1";
import "bootstrap-icons/font/bootstrap-icons.css";
import styles from "../styles/Home.module.css";



export default function Home() {

  
  
  return (
    <>
<div>testeo</div>

      <Footer />
      <Script1 />
    </>
  );
}
