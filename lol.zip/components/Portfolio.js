import Image from "next/image";
import jQuery from "jquery";
import $ from "jquery";
import portafolio_1 from "../styles/assets/img/portfolio-1.jpg"
import portafolio_2 from "../styles/assets/img/portfolio-2.jpg"
import portafolio_3 from "../styles/assets/img/portfolio-3.jpg"
import portafolio_4 from "../styles/assets/img/portfolio-4.jpg"
import portafolio_5 from "../styles/assets/img/portfolio-5.jpg"
import portafolio_6 from "../styles/assets/img/portfolio-6.jpg"


if (typeof window !== "undefined") {

  }
  


function Portfolio() {
  return (
    <>

    </>
  );
}

export default Portfolio;
