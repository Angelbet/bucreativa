
function Scrip1() {
  return <div></div>;
}

export default Scrip1;
